/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp1.Ej4;

/**
 *
 * @author valen
 */
public class NewMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int a = 1, b = 2;
    Integer c = 3, d = 4;
    SwapValores.swap1(a,b);
    SwapValores.swap2(c,d);
    System.out.println("a=" + a + " b=" + b) ;
    System.out.println("c=" + c + " d=" + d) ;
    }
    
}
