/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp1.Ej1;

import tp1.Ej1.Ej1;

/**
 *
 * @author valen
 */
public class pruebaEj1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Ej1.mostrarFor(3, 5);
        System.out.println("---------------------------------------");
        Ej1.mostrarWhile(3, 5);
        System.out.println("---------------------------------------");
        Ej1.mostrarRecursivo(3, 5);
    }
    
}
